package com.reclient;

import java.nio.file.Files;
import java.nio.file.Path;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.reclient.module.HudModule;
import com.reclient.module.Module;
import com.reclient.module.ModuleManager;
import com.reclient.setting.Setting;
import net.fabricmc.loader.api.FabricLoader;

/** Saves everything (theme, modules, positions, settings) to config/reclient.json. */
public final class ReConfig {
	private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("reclient.json");
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

	private ReConfig() {}

	public static void save() {
		try {
			JsonObject root = new JsonObject();

			JsonObject theme = new JsonObject();
			theme.addProperty("hue", Theme.hue);
			theme.addProperty("saturation", Theme.sat);
			theme.addProperty("rainbow", Theme.rainbow);
			theme.addProperty("panelAlpha", Theme.panelAlpha);
			theme.addProperty("textShadow", Theme.textShadow);
			theme.addProperty("radius", Theme.radius);
			root.add("theme", theme);

			JsonObject mods = new JsonObject();
			for (Module m : ModuleManager.MODULES) {
				JsonObject o = new JsonObject();
				o.addProperty("enabled", m.enabled);
				if (m instanceof HudModule h) {
					o.addProperty("x", h.x);
					o.addProperty("y", h.y);
					o.addProperty("scale", h.scale);
				}
				JsonObject s = new JsonObject();
				for (Setting st : m.settings) s.add(st.name, st.save());
				o.add("settings", s);
				mods.add(m.name, o);
			}
			root.add("modules", mods);
			root.add("performance", Performance.toJson());

			Files.writeString(FILE, GSON.toJson(root));
		} catch (Exception e) {
			ReClient.LOGGER.error("Failed to save ReClient config", e);
		}
	}

	public static void load() {
		if (!Files.exists(FILE)) {
			save();
			return;
		}
		try {
			JsonObject root = JsonParser.parseString(Files.readString(FILE)).getAsJsonObject();

			if (root.has("theme")) {
				JsonObject t = root.getAsJsonObject("theme");
				if (t.has("hue")) Theme.hue = t.get("hue").getAsFloat();
				if (t.has("saturation")) Theme.sat = t.get("saturation").getAsFloat();
				if (t.has("rainbow")) Theme.rainbow = t.get("rainbow").getAsBoolean();
				if (t.has("panelAlpha")) Theme.panelAlpha = t.get("panelAlpha").getAsInt();
				if (t.has("textShadow")) Theme.textShadow = t.get("textShadow").getAsBoolean();
				if (t.has("radius")) Theme.radius = t.get("radius").getAsInt();
			}

			if (root.has("modules")) {
				JsonObject mods = root.getAsJsonObject("modules");
				for (Module m : ModuleManager.MODULES) {
					if (!mods.has(m.name)) continue;
					JsonObject o = mods.getAsJsonObject(m.name);
					if (o.has("enabled")) m.enabled = o.get("enabled").getAsBoolean();
					if (m instanceof HudModule h) {
						if (o.has("x")) h.x = o.get("x").getAsInt();
						if (o.has("y")) h.y = o.get("y").getAsInt();
						if (o.has("scale")) h.scale = o.get("scale").getAsFloat();
					}
					if (o.has("settings")) {
						JsonObject s = o.getAsJsonObject("settings");
						for (Setting st : m.settings) {
							if (s.has(st.name)) st.load(s.get(st.name));
						}
					}
				}
			}

			if (root.has("performance")) Performance.fromJson(root.getAsJsonObject("performance"));
		} catch (Exception e) {
			ReClient.LOGGER.error("Failed to load ReClient config, using defaults", e);
		}
	}
}
