# ReClient

A smooth, customisable Fabric client mod for Minecraft 1.21.x. Press **Right Shift** in-game to open the menu.

## Features
- **Smooth animated menu** (Right Shift): Modules, Performance and Theme tabs
- **9 HUD modules**: FPS, CPS, Ping, Coordinates, Direction, Clock, Memory, Keystrokes, Armor Status
- **HUD editor**: drag modules anywhere, scroll to resize, right-click to reset (snaps to edges/centre)
- **Utility**: Zoom (hold C), Toggle Sprint, Fullbright
- **Performance presets**: Potato / Balanced / Quality, with a one-click "restore my original settings"
- **Theme**: accent colour swatches, hue/saturation, rainbow accent, HUD opacity, corner radius, text shadow
- Everything saves to `config/reclient.json`

## Build
1. Install **JDK 21**.
2. In this folder run: `./gradlew build` (Windows: `gradlew.bat build`)
3. Your mod is `build/libs/reclient-1.0.0.jar`

## Install
1. Install the Fabric loader for Minecraft 1.21.x and Fabric API.
2. Put `reclient-1.0.0.jar` in your `.minecraft/mods` folder.

## For more FPS
ReClient's presets tune vanilla video options. For the biggest boost also add
**Sodium, Lithium, FerriteCore, EntityCulling** (and Iris for shaders) to the mods folder.

## Other Minecraft versions
Change `minecraft_version` / `fabric_api_version` in `gradle.properties`. 1.21 to 1.21.1 should work as is.
1.21.2+ changed some rendering APIs, so a few lines in `ReScreen`, `HudModule` and `ReClient` may need updates.

## Project layout
- `ReClient.java`: entry point, key binds, event hooks
- `module/`: all modules (add a new one in `ModuleManager.init()`)
- `ui/ReScreen.java`: the Right Shift menu, `ui/HudEditorScreen.java`: HUD editor
- `Theme.java`, `Performance.java`, `ReConfig.java`
